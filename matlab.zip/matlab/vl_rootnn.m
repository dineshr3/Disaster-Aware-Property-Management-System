function root = vl_rootnn()

root = fileparts(fileparts(mfilename('fullpath'))) ;
